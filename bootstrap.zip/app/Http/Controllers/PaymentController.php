<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function post(Request $request) {

    }
    public function result(Request $request) {

    }
}
